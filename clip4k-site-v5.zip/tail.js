// tail.js - дописывает в видеодорожку MP4 хвост из крошечных "пустых" семплов.
// Видео и звук не перекодируются: меняются только таблицы контейнера.
// Это порт patch_tail.py; результат должен совпадать с ним байт в байт.

const CONTAINERS = new Set(["moov", "trak", "mdia", "minf", "stbl"]);

export const DEFAULT_PAD = 9112;
// Один пустой семпл: длина NAL = 4 и сам NAL из четырёх нулей (тип 0).
export const DEFAULT_SAMPLE = new Uint8Array([0, 0, 0, 4, 0, 0, 0, 0]);

const u32 = (u, o) => ((u[o] << 24) | (u[o + 1] << 16) | (u[o + 2] << 8) | u[o + 3]) >>> 0;
const w32 = (u, o, v) => { u[o] = (v >>> 24) & 255; u[o + 1] = (v >>> 16) & 255; u[o + 2] = (v >>> 8) & 255; u[o + 3] = v & 255; };
const cc = (u, o) => String.fromCharCode(u[o], u[o + 1], u[o + 2], u[o + 3]);

function concat(list) {
  let n = 0;
  for (const a of list) n += a.length;
  const out = new Uint8Array(n);
  let o = 0;
  for (const a of list) { out.set(a, o); o += a.length; }
  return out;
}

function parseBoxes(u, start, end) {
  const boxes = [];
  let pos = start;
  while (pos + 8 <= end) {
    let size = u32(u, pos);
    const type = cc(u, pos + 4);
    let hdr = 8;
    if (size === 1) {
      size = u32(u, pos + 8) * 4294967296 + u32(u, pos + 12);
      hdr = 16;
    } else if (size === 0) {
      size = end - pos;
    }
    if (size < hdr || pos + size > end) throw new Error("битый блок " + type + " на позиции " + pos);
    boxes.push({ type, pos, size, hdr });
    pos += size;
  }
  return boxes;
}

function parseTree(u, start, end) {
  return parseBoxes(u, start, end).map(b =>
    CONTAINERS.has(b.type)
      ? { type: b.type, children: parseTree(u, b.pos + b.hdr, b.pos + b.size), payload: null }
      : { type: b.type, children: null, payload: u.subarray(b.pos + b.hdr, b.pos + b.size) });
}

function serialize(box) {
  let body;
  if (box.children) body = concat(box.children.map(serialize));
  else body = box.payload;
  const out = new Uint8Array(8 + body.length);
  w32(out, 0, 8 + body.length);
  for (let i = 0; i < 4; i++) out[4 + i] = box.type.charCodeAt(i);
  out.set(body, 8);
  return out;
}

const find = (box, t) => (box.children || []).find(c => c.type === t) || null;
const findAll = (box, t) => (box.children || []).filter(c => c.type === t);
const stblOf = trak => find(find(find(trak, "mdia"), "minf"), "stbl");

function handlerType(trak) {
  const mdia = find(trak, "mdia");
  const hdlr = mdia && find(mdia, "hdlr");
  return hdlr ? cc(hdlr.payload, 8) : null;
}

function readStts(p) {
  const n = u32(p, 4);
  const e = [];
  for (let i = 0; i < n; i++) e.push([u32(p, 8 + 8 * i), u32(p, 12 + 8 * i)]);
  return e;
}

function writeStts(entries) {
  const out = new Uint8Array(8 + 8 * entries.length);
  w32(out, 4, entries.length);
  entries.forEach(([c, d], i) => { w32(out, 8 + 8 * i, c); w32(out, 12 + 8 * i, d); });
  return out;
}

function patchVideoTrak(trak, pad, sample, trim, explicitStts) {
  const stbl = stblOf(trak);

  // stsz: размеры семплов
  const stsz = find(stbl, "stsz");
  const uniform = u32(stsz.payload, 4);
  const count = u32(stsz.payload, 8);
  const total = count + pad;
  const nz = new Uint8Array(12 + 4 * total);
  w32(nz, 8, total);
  for (let i = 0; i < count; i++) {
    w32(nz, 12 + 4 * i, uniform || u32(stsz.payload, 12 + 4 * i));
  }
  for (let i = 0; i < pad; i++) w32(nz, 12 + 4 * (count + i), sample.length);
  stsz.payload = nz;

  // stts: длительности
  const stts = find(stbl, "stts");
  let entries = readStts(stts.payload);
  if (trim && entries.length) {
    const last = entries[entries.length - 1];
    if (last[0] === 1) entries[entries.length - 1] = [1, 1];
    else { entries[entries.length - 1] = [last[0] - 1, last[1]]; entries.push([1, 1]); }
  }
  const realTotal = entries.reduce((s, [c, d]) => s + c * d, 0);
  if (explicitStts) entries.push([pad, 1]);
  const merged = [];
  for (const [c, d] of entries) {
    if (merged.length && merged[merged.length - 1][1] === d) merged[merged.length - 1][0] += c;
    else merged.push([c, d]);
  }
  stts.payload = writeStts(merged);

  // ctts: только в явном режиме
  const ctts = find(stbl, "ctts");
  if (ctts && explicitStts) {
    const p = ctts.payload;
    const n = u32(p, 4);
    const out = new Uint8Array(p.length + 8);
    out.set(p, 0);
    w32(out, 4, n + 1);
    w32(out, p.length, pad);
    w32(out, p.length + 4, 0);
    ctts.payload = out;
  }

  // stsc: пустые семплы лежат одним новым куском
  const stco = find(stbl, "stco");
  const co64 = find(stbl, "co64");
  const nChunks = u32((stco || co64).payload, 4);
  const stsc = find(stbl, "stsc");
  const sp = stsc.payload;
  const sn = u32(sp, 4);
  const so = new Uint8Array(sp.length + 12);
  so.set(sp, 0);
  w32(so, 4, sn + 1);
  w32(so, sp.length, nChunks + 1);
  w32(so, sp.length + 4, pad);
  w32(so, sp.length + 8, 1);
  stsc.payload = so;

  return { realTotal, framesBefore: count };
}

function shiftAllOffsets(moov, delta) {
  if (!delta) return;
  for (const trak of findAll(moov, "trak")) {
    const stbl = stblOf(trak);
    const stco = find(stbl, "stco");
    const co64 = find(stbl, "co64");
    if (stco) {
      const p = stco.payload.slice();
      const n = u32(p, 4);
      for (let i = 0; i < n; i++) w32(p, 8 + 4 * i, u32(p, 8 + 4 * i) + delta);
      stco.payload = p;
    }
    if (co64) {
      const p = co64.payload.slice();
      const n = u32(p, 4);
      const dv = new DataView(p.buffer, p.byteOffset, p.byteLength);
      for (let i = 0; i < n; i++) dv.setBigUint64(8 + 8 * i, dv.getBigUint64(8 + 8 * i) + BigInt(delta));
      co64.payload = p;
    }
  }
}

function appendChunkOffset(trak, offset) {
  const stbl = stblOf(trak);
  const stco = find(stbl, "stco");
  if (stco) {
    if (offset >= 4294967296) throw new Error("файл больше 4 ГБ не поддерживается");
    const p = stco.payload;
    const out = new Uint8Array(p.length + 4);
    out.set(p, 0);
    w32(out, 4, u32(p, 4) + 1);
    w32(out, p.length, offset);
    stco.payload = out;
  } else {
    const co64 = find(stbl, "co64");
    const p = co64.payload;
    const out = new Uint8Array(p.length + 8);
    out.set(p, 0);
    w32(out, 4, u32(p, 4) + 1);
    new DataView(out.buffer).setBigUint64(p.length, BigInt(offset));
    co64.payload = out;
  }
}

function setDurations(moov, trak, realTotal) {
  const mdhd = find(find(trak, "mdia"), "mdhd");
  const p = mdhd.payload.slice();
  const dv = new DataView(p.buffer, p.byteOffset, p.byteLength);
  let ts;
  if (p[0] === 1) { ts = u32(p, 20); dv.setBigUint64(24, BigInt(realTotal)); }
  else { ts = u32(p, 12); w32(p, 16, realTotal); }
  mdhd.payload = p;

  const mvhd = find(moov, "mvhd");
  const mvTs = u32(mvhd.payload, mvhd.payload[0] === 1 ? 20 : 12);
  const tkhd = find(trak, "tkhd");
  const t = tkhd.payload.slice();
  const dur = Math.round(realTotal * mvTs / ts);
  if (t[0] === 1) new DataView(t.buffer, t.byteOffset, t.byteLength).setBigUint64(28, BigInt(dur));
  else w32(t, 20, dur);
  tkhd.payload = t;
}

function readInfo(moov) {
  const trak = findAll(moov, "trak").find(t => handlerType(t) === "vide");
  if (!trak) return null;
  const stbl = stblOf(trak);
  const stsd = find(stbl, "stsd");
  const sampleEntry = stsd ? cc(stsd.payload, 12) : "";
  const mdhd = find(find(trak, "mdia"), "mdhd").payload;
  const timescale = u32(mdhd, mdhd[0] === 1 ? 20 : 12);
  const tkhd = find(trak, "tkhd").payload;
  const wOff = tkhd[0] === 1 ? 88 : 76;
  const width = u32(tkhd, wOff) / 65536;
  const height = u32(tkhd, wOff + 4) / 65536;
  const stts = readStts(find(stbl, "stts").payload);
  const frames = stts.reduce((s, [c]) => s + c, 0);
  const ticks = stts.reduce((s, [c, d]) => s + c * d, 0);
  const sizes = u32(find(stbl, "stsz").payload, 8);
  return { trak, sampleEntry, timescale, width, height, frames, samples: sizes, seconds: ticks / timescale, fps: ticks ? frames * timescale / ticks : 0 };
}

// Проверка файла без изменений: подходит ли он для добавления хвоста.
export function inspectMp4(input) {
  const u = input instanceof Uint8Array ? input : new Uint8Array(input);
  const top = parseBoxes(u, 0, u.length);
  if (top.some(b => b.type === "moof")) return { ok: false, reason: "fragmented" };
  const m = top.filter(b => b.type === "moov");
  if (m.length !== 1) return { ok: false, reason: "no-moov" };
  const moov = { type: "moov", children: parseTree(u, m[0].pos + m[0].hdr, m[0].pos + m[0].size), payload: null };
  const info = readInfo(moov);
  if (!info) return { ok: false, reason: "no-video" };
  if (info.sampleEntry !== "avc1" && info.sampleEntry !== "avc3") return { ok: false, reason: "not-h264", codec: info.sampleEntry };
  const { trak, ...rest } = info;
  return { ok: true, ...rest };
}

// Главная функция. Возвращает { blob, info }.
export function addTail(input, opts = {}) {
  const pad = opts.pad ?? DEFAULT_PAD;
  const sample = opts.sample ?? DEFAULT_SAMPLE;
  const trim = opts.trim ?? true;
  const explicitStts = opts.explicitStts ?? false;
  const u = input instanceof Uint8Array ? input : new Uint8Array(input);

  const top = parseBoxes(u, 0, u.length);
  if (top.some(b => b.type === "moof")) throw new Error("фрагментированный MP4 не поддерживается");
  const mi = top.filter(b => b.type === "moov");
  if (mi.length !== 1) throw new Error("не найден блок moov");
  const { pos: mPos, size: mSize, hdr: mHdr } = mi[0];
  const mEnd = mPos + mSize;
  const moovFirst = top.some(b => b.type === "mdat" && b.pos > mPos);

  let stats = null;
  const build = (padOffset, shift) => {
    const moov = { type: "moov", payload: null, children: parseTree(u, mPos + mHdr, mEnd) };
    const trak = findAll(moov, "trak").find(t => handlerType(t) === "vide");
    if (!trak) throw new Error("нет видеодорожки");
    shiftAllOffsets(moov, shift);
    const { realTotal, framesBefore } = patchVideoTrak(trak, pad, sample, trim, explicitStts);
    appendChunkOffset(trak, padOffset);
    if (trim) setDurations(moov, trak, realTotal);
    stats = { framesBefore };
    return serialize(moov);
  };

  const padData = new Uint8Array(sample.length * pad);
  for (let i = 0; i < pad; i++) padData.set(sample, i * sample.length);
  const padBox = new Uint8Array(8 + padData.length);
  w32(padBox, 0, 8 + padData.length);
  padBox.set([0x6d, 0x64, 0x61, 0x74], 4);
  padBox.set(padData, 8);

  let parts;
  if (moovFirst) {
    const probe = build(0, 0);
    const shift = probe.length - mSize;
    const beforePad = u.length - mSize + probe.length;
    const moovBytes = build(beforePad + 8, shift);
    if (moovBytes.length !== probe.length) throw new Error("внутренняя ошибка: размер moov изменился");
    parts = [u.subarray(0, mPos), moovBytes, u.subarray(mEnd), padBox];
  } else {
    const headLen = mPos + (u.length - mEnd);
    const moovBytes = build(headLen + 8, 0);
    parts = [u.subarray(0, mPos), u.subarray(mEnd), padBox, moovBytes];
  }

  const blob = new Blob(parts, { type: "video/mp4" });
  return { blob, parts, info: { pad, frames: stats.framesBefore, moovFirst } };
}
